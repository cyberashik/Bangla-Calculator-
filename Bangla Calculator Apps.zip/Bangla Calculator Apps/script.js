// বাংলা সংখ্যা থেকে ইংরেজি সংখ্যা রূপান্তর
function convertToEnglish(text) {
    let banglaNumbers = {'০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
                         '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'};
    return text.replace(/[০-৯]/g, m => banglaNumbers[m]);
}

// ইংরেজি সংখ্যা থেকে বাংলা সংখ্যা রূপান্তর
function convertToBangla(text) {
    let englishNumbers = {'0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
                          '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'};
    return text.replace(/[0-9]/g, m => englishNumbers[m]);
}

// ইনপুটে সংখ্যা যোগ করা
function appendValue(value) {
    document.getElementById("display").value += value;
}

// স্ক্রিন ক্লিয়ার করা
function clearDisplay() {
    document.getElementById("display").value = "";
}

// ফলাফল গণনা করা
function calculateResult() {
    try {
        let expression = document.getElementById("display").value;
        let convertedExpression = convertToEnglish(expression).replace(/×/g, '*').replace(/÷/g, '/');
        let result = eval(convertedExpression);
        document.getElementById("display").value = convertToBangla(result.toString());
    } catch (error) {
        alert("ভুল ইনপুট! সঠিক সংখ্যা ও অপারেটর ব্যবহার করুন।");
    }
}